//
//  MLiPadRightViewController.m
//  MinPairs
//
//  Created by Brandon on 2014-04-29.
//  Copyright (c) 2014 MobiLearning. All rights reserved.
//

#import "MLiPadRightViewController.h"

@interface MLiPadRightViewController ()
@end

@implementation MLiPadRightViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)updateView:(UIView *)view
{
    if (_popover != nil)
    {
        [_popover dismissPopoverAnimated:YES];
    }
    
    if (view == nil)
    {
        [[self view] setNeedsDisplay];
    }
    else
    {
        self.view = view;
    }
}

@end
