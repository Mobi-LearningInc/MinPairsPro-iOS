//
//  MLiPadRightViewController.h
//  MinPairs
//
//  Created by Brandon on 2014-04-29.
//  Copyright (c) 2014 MobiLearning. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MLiPadUpdateViewDelegate.h"

@interface MLiPadRightViewController : UIViewController<MLiPadUpdateViewDelegate>
@property (nonatomic, strong) UIPopoverController* popover;
@end
