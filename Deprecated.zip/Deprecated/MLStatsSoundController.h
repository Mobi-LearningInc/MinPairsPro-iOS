//
//  MLStatsSoundController.h
//  MinPairs
//
//  Created by Brandon on 2014-05-02.
//  Copyright (c) 2014 MobiLearning. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MLStatsSoundController : UITableViewController

@end
